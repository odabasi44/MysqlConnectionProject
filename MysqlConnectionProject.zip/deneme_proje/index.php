<!DOCTYPE html>
<html>
<head>
	<title>Crud İşlemleri</title>
</head>
<body>
		<h1>Veritabanı PDO Kayıt İşlemleri</h1>
		<hr>
		<hr>
		<br>
		

		<form action="islem.php" method="POST">
			 <input type="text" required="" name="bilgilerim_ad" placeholder="Adınızı Giriniz...">
			 <input type="text" required="" name="bilgilerim_soyad" placeholder="Soyadınızı Giriniz...">
			 <input type="email" required="" name="bilgilerim_mail" placeholder="Mailinizi Giriniz...">
			 <input type="text" required="" name="bilgilerim_ozgecmis" placeholder="Özgeçmişinizi Giriniz...">
			 <button type="submit" name="insertislemi">Formu Gönder</button>

		</form>
<?php 
		if ($_GET['durum']=="ok"){
			echo "İşlem Başarılı";

		} else if ($_GET['durum']=="no"){
			echo "İşlem Başarısız";
		}
		?>

</body>
</html>
