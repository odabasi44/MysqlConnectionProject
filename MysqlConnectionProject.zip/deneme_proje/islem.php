<?php
require_once 'baglan.php';
 if (isset($_POST['insertislemi'])){

  $kaydet=$db->prepare("INSERT into bilgilerim set
  	bilgilerim_ad=:bilgilerim_ad,
  	bilgilerim_soyad=:bilgilerim_soyad,
  	bilgilerim_mail=:bilgilerim_mail,
  	bilgilerim_ozgecmis=:bilgilerim_ozgecmis
	");
  $insert=$kaydet->execute(array(

'bilgilerim_ad'=>$_POST['bilgilerim_ad'],
'bilgilerim_soyad'=>$_POST['bilgilerim_soyad'],
'bilgilerim_mail'=>$_POST['bilgilerim_mail'],
'bilgilerim_ozgecmis'=>$_POST['bilgilerim_ozgecmis']
  ));
if ($insert) {
	//echo "KAYIT BAŞARILI.!";
	Header("Location:index.php?durum=ok");
	exit;

 } else {
 	//echo "ÜZGÜNÜM. GİRDİĞİNİZ BİLGİLER BİR HATADAN DOLAYI KAYDEDİLMEDİ.";
 	Header("Location:index.php?durum=no");
	exit;
 }
}

?>